# CapacitaceValueExtraction
Extract 3 ,4 digit capacitance code from partNumber
